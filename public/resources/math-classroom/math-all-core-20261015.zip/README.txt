七、八年級上下冊章節核心課堂包 / Year 7–8 upper- and lower-volume core practice
53 original bilingual packs, 848 fixed original questions, 318 PDF editions.
Each pack has en and zh-Hant editions of student, supplement and teacher papers.
student: blank two-page A4 core worksheets, including worked/guided spaces.
supplement: further practice and extensions, separately printed.
teacher: reference answers and rubrics; keep separate from student copies.

共53個原創雙語課堂包、848道固定題、318份PDF。
student為兩頁A4留白核心；supplement為補練及進階；teacher附參考解答及準則。
配合相應正文課時學習後使用，亦可作章末複習；軟件驗收不等同教師試教或學習成效證據。
只收錄通過本機紙本驗收的已登記題組，不包含測試fixture、備份或原教材PDF。
https://skckenneth.github.io/zh/teaching/classroom-packs/curriculum/
https://skckenneth.github.io/zh/teaching/classroom-packs/curriculum/lower/
