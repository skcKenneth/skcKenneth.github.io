"""Two-species graph Turing instability and a posteriori spectral-band tests."""
import numpy as np


def schnakenberg_jacobian(a: float = 0.1, b: float = 0.9) -> np.ndarray:
    u = a + b
    v = b / (u * u)
    return np.array([[-1 + 2*u*v, u*u], [-2*u*v, -u*u]], dtype=float)


def turing_band(J: np.ndarray, du: float, dv: float):
    """Open unstable interval when homogeneous steady state and trace are stable.

    Assumptions: trace(J)<0, det(J)>0, du,dv>0. For all q>=0,
    trace(J-qD)<0, hence instability iff det(J-qD)<0.
    """
    if du <= 0 or dv <= 0 or np.trace(J) >= 0 or np.linalg.det(J) <= 0:
        raise ValueError('requires a stable homogeneous equilibrium and positive diffusion')
    coeff = dv*J[0, 0] + du*J[1, 1]
    disc = coeff**2 - 4*du*dv*np.linalg.det(J)
    if coeff <= 0 or disc <= 0:
        return None
    qlo = (coeff - np.sqrt(disc)) / (2*du*dv)
    qhi = (coeff + np.sqrt(disc)) / (2*du*dv)
    if qhi <= 0:
        return None
    return max(float(qlo), 0.0), float(qhi)


def max_mode_growth(J, du, dv, q):
    return float(np.max(np.linalg.eigvals(J - q*np.diag([du, dv])).real))


def verdict(L, band, tol=1e-9):
    vals = np.linalg.eigvalsh(L)
    if band is None:
        return 'stable'
    low, high = band
    return 'unstable' if np.any((vals[1:] > low + tol) & (vals[1:] < high - tol)) else 'stable'


def certify_original_from_sparse_eigs(Ls, eps, band, tol=1e-9):
    """A posteriori guaranteed conclusion on ORIGINAL graph from SPARSE eigs.

    If (1-eps)L <= Ls <= (1+eps)L and eps<1, then the ordered
    eigenvalues of original L lie in [ls/(1+eps), ls/(1-eps)].
    All intervals must exclude U to conclude STABLE; one interval
    entirely contained in U suffices for UNSTABLE. Otherwise INCONCLUSIVE.
    This is a deterministic algebraic consequence, not an original theorem.
    """
    if band is None:
        return 'stable'
    if not (0 <= eps < 1):
        return 'inconclusive'
    low, high = band
    ls = np.linalg.eigvalsh(Ls)[1:]
    left = np.maximum(ls / (1 + eps), 0)
    right = ls / (1 - eps)
    if np.any((left > low + tol) & (right < high - tol)):
        return 'unstable'
    if np.all((right <= low - tol) | (left >= high + tol)):
        return 'stable'
    return 'inconclusive'


def full_linear_growth(L, J, du, dv):
    """Independent 2n-by-2n Kronecker matrix check of fastest growth rate."""
    n = L.shape[0]
    A = np.kron(np.eye(n), J) - np.kron(L, np.diag([du, dv]))
    return float(np.max(np.linalg.eigvals(A).real))
