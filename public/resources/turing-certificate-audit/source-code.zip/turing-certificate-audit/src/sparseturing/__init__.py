"""Spectral sparsification and Turing onset: verified, minimal research code."""
