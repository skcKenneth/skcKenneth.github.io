"""Small-graph reference Laplacians and unbiased with-replacement edge samplers."""
from __future__ import annotations
import numpy as np


def make_graph(n: int, seed: int, long_edge_probability: float = 0.18):
    """Connected random small-world graph as array (i, j, weight), i<j."""
    if n < 5:
        raise ValueError('n must be >= 5')
    rng = np.random.default_rng(seed)
    edges = {}
    # A connected 2-neighbor ring backbone.
    for i in range(n):
        for hop in (1, 2):
            j = (i + hop) % n
            pair = tuple(sorted((i, j)))
            edges[pair] = float(rng.uniform(0.80, 1.20))
    for i in range(n):
        for j in range(i + 1, n):
            if (i, j) not in edges and rng.random() < long_edge_probability:
                edges[i, j] = float(rng.uniform(0.65, 1.35))
    return np.asarray([(i, j, w) for (i, j), w in sorted(edges.items())], dtype=float)


def laplacian(n: int, edges: np.ndarray):
    L = np.zeros((n, n), dtype=float)
    for i_float, j_float, w in edges:
        i, j = int(i_float), int(j_float)
        if w <= 0 or i == j or not (0 <= i < n and 0 <= j < n):
            raise ValueError('positive off-diagonal edge weights are required')
        L[i, i] += w
        L[j, j] += w
        L[i, j] -= w
        L[j, i] -= w
    return L


def effective_resistance_probabilities(n: int, edges: np.ndarray):
    """Exact leverage scores w_ij R_ij for small connected graphs."""
    L = laplacian(n, edges)
    vals, vecs = np.linalg.eigh(L)
    if vals[1] < 1e-10:
        raise ValueError('reference graph is disconnected')
    Lplus = (vecs[:, 1:] / vals[1:]) @ vecs[:, 1:].T
    scores = np.asarray([w * (Lplus[int(i), int(i)] + Lplus[int(j), int(j)]
                 - 2 * Lplus[int(i), int(j)]) for i, j, w in edges])
    return scores / scores.sum(), scores


def sample_edges(edges: np.ndarray, draws: int, seed: int,
                 probabilities: np.ndarray | None = None):
    """Independent with-replacement edge sampling and standard inverse-probability reweighting.

    Each sampled edge e contributes w_e/(draws * p_e). Duplicate edges aggregate.
    Sampling is unbiased in Laplacian expectation; a *particular* realization need
    not be a high-quality spectral sparsifier. Verify quality a posteriori.
    """
    if draws <= 0:
        raise ValueError('draws must be positive')
    m = len(edges)
    p = np.full(m, 1 / m) if probabilities is None else np.asarray(probabilities, dtype=float)
    if p.shape != (m,) or np.any(p <= 0) or not np.isclose(p.sum(), 1):
        raise ValueError('invalid sampling probabilities')
    rng = np.random.default_rng(seed)
    picks = rng.choice(m, size=draws, replace=True, p=p)
    count = np.bincount(picks, minlength=m)
    chosen = count > 0
    result = edges[chosen].copy()
    result[:, 2] = result[:, 2] * count[chosen] / (draws * p[chosen])
    return result


def spectral_distortion(L: np.ndarray, Ls: np.ndarray) -> float:
    """Sharp *a posteriori* relative Loewner error on orthogonal complement of 1.

    Full eigendecomposition of L is required in this reference implementation.
    This should NOT be presented as a scalable certificate.
    """
    if L.shape != Ls.shape or not np.allclose(L, L.T) or not np.allclose(Ls, Ls.T):
        raise ValueError('Laplacians must be symmetric, same size')
    values, Q = np.linalg.eigh(L)
    if values[1] < 1e-12:
        raise ValueError('reference Laplacian must be connected')
    U = Q[:, 1:] / np.sqrt(values[1:])
    relative = U.T @ Ls @ U
    ratios = np.linalg.eigvalsh(relative)
    return float(max(abs(ratios[0] - 1.0), abs(ratios[-1] - 1.0)))
