import numpy as np
from sparseturing.graphs import make_graph, laplacian, sample_edges, spectral_distortion
from sparseturing.dispersion import (
    schnakenberg_jacobian, turing_band, max_mode_growth,
    verdict, certify_original_from_sparse_eigs, full_linear_growth
)


def test_known_schnakenberg_turing_band():
    J = schnakenberg_jacobian()
    lo, hi = turing_band(J, 0.1, 1.0)
    assert np.isclose(lo, 2.0, atol=1e-10)
    assert np.isclose(hi, 5.0, atol=1e-10)


def test_dispersion_signs():
    J = schnakenberg_jacobian()
    assert max_mode_growth(J, 0.1, 1.0, 0.0) < 0
    assert max_mode_growth(J, 0.1, 1.0, 3.0) > 0
    assert max_mode_growth(J, 0.1, 1.0, 7.0) < 0


def test_missing_turing_band():
    J = schnakenberg_jacobian()
    assert turing_band(J, 1., 1.) is None


def test_exact_certificate_agrees_with_true():
    J = schnakenberg_jacobian()
    band = turing_band(J, 0.1, 1.0)
    L = laplacian(18, make_graph(18, 2))
    for scale in [0.1, 0.35, 1., 4., 18.]:
        status = verdict(L*scale, band)
        assert certify_original_from_sparse_eigs(L*scale, 0., band) == status


def test_scaled_eigenvalue_enclosure_is_correct():
    L = laplacian(18, make_graph(18, 9))
    Ls = L*1.1
    eps = spectral_distortion(L, Ls)
    lo = np.linalg.eigvalsh(Ls)[1:]/(1+eps)
    hi = np.linalg.eigvalsh(Ls)[1:]/(1-eps)
    truth = np.linalg.eigvalsh(L)[1:]
    assert np.all(lo <= truth + 1e-9)
    assert np.all(hi >= truth - 1e-9)


def test_full_linear_growth_matches_modal_growth():
    J = schnakenberg_jacobian()
    L = laplacian(9, make_graph(9, 4))
    modal = max(max_mode_growth(J,.1,1.,q) for q in np.linalg.eigvalsh(L))
    assert np.isclose(modal, full_linear_growth(L,J,.1,1.),atol=1e-10)


def test_spectral_certificate_never_gives_wrong_definitive_answer():
    band = turing_band(schnakenberg_jacobian(), 0.1, 1.0)
    L = laplacian(18, make_graph(18, 42, .16))
    for s in [0.15, 0.40, 0.7, 1.3, 4.0]:
        for seed in range(5):
            L0 = L*s
            Es = sample_edges(make_graph(18,42,.16) * np.array([1.,1.,s]), 35, seed)
            Ls = laplacian(18, Es)
            eps = spectral_distortion(L0,Ls)
            cert = certify_original_from_sparse_eigs(Ls,eps,band)
            assert cert == 'inconclusive' or cert == verdict(L0, band)


def test_large_distortion_is_inconclusive():
    L = laplacian(8, make_graph(8, 11))
    band = (2.,5.)
    assert certify_original_from_sparse_eigs(L,1.0,band) == 'inconclusive'
