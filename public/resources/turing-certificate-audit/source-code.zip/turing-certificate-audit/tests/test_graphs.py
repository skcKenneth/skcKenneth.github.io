import numpy as np
from sparseturing.graphs import (
    make_graph, laplacian, effective_resistance_probabilities,
    sample_edges, spectral_distortion
)


def test_graph_connected_and_mass_laplacian():
    edges = make_graph(18, 31, 0.1)
    L = laplacian(18, edges)
    assert np.allclose(L, L.T)
    assert np.allclose(L.sum(axis=0), 0.0)
    assert np.linalg.eigvalsh(L)[1] > 0


def test_laplacian_quadratic_form():
    edges = make_graph(16, 5, 0.1)
    L = laplacian(16, edges)
    x = np.linspace(-1, 1, 16)
    edge_energy = sum(w*(x[int(i)]-x[int(j)])**2 for i,j,w in edges)
    assert np.isclose(x @ L @ x, edge_energy)


def test_resistance_leverages_sum_to_n_minus_one():
    edges = make_graph(12, 1, 0.3)
    p, s = effective_resistance_probabilities(12, edges)
    assert np.all(p > 0)
    assert np.isclose(p.sum(), 1.0)
    assert np.isclose(s.sum(), 11.0, atol=1e-8)


def test_two_node_sampler_exact():
    edges = np.array([[0,1,3.0]])
    for n_draws in [1, 2, 40]:
        E = sample_edges(edges, n_draws, seed=7)
        assert np.allclose(E, edges)


def test_spectral_distortion_zero_for_exact_graph():
    edges = make_graph(11, 2)
    L = laplacian(11, edges)
    assert spectral_distortion(L, L) < 1e-10


def test_spectral_distortion_for_scaled_graph():
    edges = make_graph(11, 2)
    L = laplacian(11, edges)
    assert np.isclose(spectral_distortion(L, 1.2*L), 0.2)


def test_sparsifier_is_positive_supported():
    edges = make_graph(14, 25)
    p, _ = effective_resistance_probabilities(14, edges)
    sparse = sample_edges(edges, 20, seed=1, probabilities=p)
    assert np.all(sparse[:,2] > 0)
    edge_keys = {tuple(e[:2]) for e in edges}
    assert all(tuple(e[:2]) in edge_keys for e in sparse)
    assert len(sparse) <= 20


def test_invalid_sampling():
    edges = make_graph(10, 23)
    try:
        sample_edges(edges, 20, 7, probabilities=np.zeros(len(edges)))
    except ValueError:
        pass
    else:
        raise AssertionError('bad probabilities not rejected')
