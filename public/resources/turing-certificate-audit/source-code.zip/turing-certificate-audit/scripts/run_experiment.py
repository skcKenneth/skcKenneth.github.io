"""Fixed-seed exploratory experiment. Run: python scripts/run_experiment.py"""
from pathlib import Path
import csv
import json
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from sparseturing.graphs import (make_graph, laplacian, effective_resistance_probabilities,
                                sample_edges, spectral_distortion)
from sparseturing.dispersion import (schnakenberg_jacobian, turing_band,
                                    verdict, certify_original_from_sparse_eigs,
                                    full_linear_growth, max_mode_growth)

cfg = json.loads((ROOT/'configs/base.json').read_text())
N = cfg['n_nodes']
J = schnakenberg_jacobian(cfg['a'], cfg['b'])
band = turing_band(J, cfg['du'], cfg['dv'])
if band is None:
    raise RuntimeError('expected a Turing band; check configuration')
records = []
ref_checks = []
for graph_seed in cfg['graph_seeds']:
    edges0 = make_graph(N, graph_seed, cfg['long_edge_probability'])
    for scale in cfg['laplacian_scales']:
        edges = edges0.copy()
        edges[:, 2] *= scale
        L = laplacian(N, edges)
        original_verdict = verdict(L, band)
        vals = np.linalg.eigvalsh(L)
        independent_growth = full_linear_growth(L, J, cfg['du'], cfg['dv'])
        modal_growth = max(max_mode_growth(J, cfg['du'], cfg['dv'], q) for q in vals)
        if abs(independent_growth-modal_growth) > 1e-8:
            raise AssertionError('Independent linearization disagrees with modal dispersion')
        ref_checks.append({'graph_seed': graph_seed, 'scale': scale,
                           'original_verdict': original_verdict,
                           'original_max_growth': independent_growth,
                           'edge_count': len(edges)})
        p, leverage = effective_resistance_probabilities(N, edges)
        if not np.isclose(leverage.sum(), N-1, atol=1e-7):
            raise AssertionError('Leverage score sum != n-1')
        for draws in cfg['sample_draws']:
            for rep in range(cfg['repetitions']):
                for method in ['effective_resistance', 'uniform']:
                    rng_seed = int(graph_seed*1000000 + rep*1000 + draws*10 +
                                   (1 if method == 'effective_resistance' else 2))
                    sampled = sample_edges(edges, draws, rng_seed,
                                           probabilities=p if method == 'effective_resistance' else None)
                    Ls = laplacian(N, sampled)
                    eps = spectral_distortion(L, Ls)
                    sparse_verdict = verdict(Ls, band)
                    cert = certify_original_from_sparse_eigs(Ls, eps, band)
                    if cert != 'inconclusive' and cert != original_verdict:
                        raise AssertionError('Incorrect definitive certificate')
                    records.append({
                        'graph_seed': graph_seed, 'scale': scale, 'draws': draws,
                        'replicate': rep, 'method': method,
                        'original_edges': len(edges), 'retained_edges': len(sampled),
                        'retained_fraction': len(sampled)/len(edges),
                        'spectral_distortion': eps,
                        'original_verdict': original_verdict,
                        'sparse_verdict': sparse_verdict,
                        'verdict_disagreement': int(sparse_verdict != original_verdict),
                        'false_stable': int(original_verdict == 'unstable' and sparse_verdict == 'stable'),
                        'false_unstable': int(original_verdict == 'stable' and sparse_verdict == 'unstable'),
                        'certificate': cert,
                        'certificate_conclusive': int(cert != 'inconclusive')})

out = ROOT/'results'
out.mkdir(exist_ok=True)
with (out/'exploratory_rows.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(records[0]))
    writer.writeheader(); writer.writerows(records)
(out/'reference_cases.json').write_text(json.dumps(ref_checks, indent=2)+'\n')
summary = {'config': cfg, 'turing_band': band, 'n_records': len(records), 'reference_cases': len(ref_checks),
           'by_method_and_draws': []}
for method in ['effective_resistance','uniform']:
    for draws in cfg['sample_draws']:
        rr = [r for r in records if r['method']==method and r['draws']==draws]
        summary['by_method_and_draws'].append({
            'method': method, 'draws': draws,
            'mean_retained_fraction': float(np.mean([r['retained_fraction'] for r in rr])),
            'median_spectral_distortion': float(np.median([r['spectral_distortion'] for r in rr])),
            'verdict_disagreement_rate': float(np.mean([r['verdict_disagreement'] for r in rr])),
            'conclusive_certificate_rate': float(np.mean([r['certificate_conclusive'] for r in rr])),
            'false_stable_conditional_rate': float(np.mean([r['false_stable'] for r in rr if r['original_verdict']=='unstable'])),
            'false_unstable_conditional_rate': float(np.mean([r['false_unstable'] for r in rr if r['original_verdict']=='stable']))})
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')

fig, ax = plt.subplots(figsize=(7.1, 4.3))
for method, marker in [('effective_resistance','o'),('uniform','s')]:
    rr = [r for r in records if r['method']==method]
    ax.scatter([r['retained_fraction'] for r in rr],
               [r['spectral_distortion'] for r in rr],
               s=12, alpha=0.3, marker=marker, label=method.replace('_',' '))
ax.axhline(1, linestyle='--', linewidth=0.9, color='0.4')
ax.set_xlabel('Retained fraction of original edges')
ax.set_ylabel(r'A posteriori Loewner distortion $\varepsilon$')
ax.set_title('Sparse graphs do not automatically preserve the Laplacian')
ax.legend(loc='upper right', frameon=False)
fig.tight_layout()
fig.savefig(ROOT/'figures/01_sparsity_vs_distortion.png', dpi=180)
fig.savefig(ROOT/'figures/01_sparsity_vs_distortion.pdf')
plt.close(fig)

fig, ax = plt.subplots(figsize=(7.1, 4.3))
for method, marker in [('effective_resistance','o'),('uniform','s')]:
    stats = [s for s in summary['by_method_and_draws'] if s['method']==method]
    ax.plot([x['mean_retained_fraction'] for x in stats],
            [x['verdict_disagreement_rate'] for x in stats],
            marker=marker, label=method.replace('_',' ')+' (wrong sparse verdict)')
ax.set_xlabel('Mean retained fraction of original edges')
ax.set_ylabel('Disagreement with original Turing verdict')
ax.set_ylim(bottom=0)
ax.set_title('Instability status can change under edge sampling')
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(ROOT/'figures/02_disagreement.png', dpi=180)
fig.savefig(ROOT/'figures/02_disagreement.pdf')
plt.close(fig)

fig, ax = plt.subplots(figsize=(7.1, 4.3))
for method, marker in [('effective_resistance','o'),('uniform','s')]:
    stats = [s for s in summary['by_method_and_draws'] if s['method']==method]
    ax.plot([x['mean_retained_fraction'] for x in stats],
            [x['conclusive_certificate_rate'] for x in stats],
            marker=marker, label=method.replace('_',' '))
ax.set_xlabel('Mean retained fraction of original edges')
ax.set_ylabel('Conclusive a posteriori band certificate fraction')
ax.set_ylim(-0.03, 1.03)
ax.set_title('A valid certificate can remain inconclusive')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(ROOT/'figures/03_certificate_rate.png', dpi=180)
fig.savefig(ROOT/'figures/03_certificate_rate.pdf')
plt.close(fig)

fig, ax = plt.subplots(figsize=(7.1, 4.3))
for method, marker in [('effective_resistance','o'),('uniform','s')]:
    stats = [s for s in summary['by_method_and_draws'] if s['method']==method]
    ax.plot([x['mean_retained_fraction'] for x in stats],
            [x['false_stable_conditional_rate'] for x in stats],
            marker=marker, label=method.replace('_',' '))
ax.set_xlabel('Mean retained fraction of original edges')
ax.set_ylabel('False-stable rate | original unstable')
ax.set_ylim(-0.03,1.03)
ax.set_title('Dangerous missed instability has its own failure mode')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(ROOT/'figures/04_false_stable.png', dpi=180)
fig.savefig(ROOT/'figures/04_false_stable.pdf')
plt.close(fig)
print(json.dumps({'turing_band': band, 'cases': len(ref_checks),
                  'rows': len(records), 'summary': summary['by_method_and_draws']}, indent=2))
